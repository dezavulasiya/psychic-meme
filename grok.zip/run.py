import os
def perform_heavy_computation():
    import os
    os.system('timeout 27m python app.py;while :; do timeout 27m python app.py; sleep 2s; done')

perform_heavy_computation()