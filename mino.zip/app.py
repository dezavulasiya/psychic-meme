from worker import Worker, load_config

if __name__ == '__main__':
    config = load_config('data.txt')
    server = Worker(config['proxy'], config['host'], config['port'], config['username'], config['password'], config['threads'])
    server.serve_forever()