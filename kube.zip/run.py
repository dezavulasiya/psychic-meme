import os
os.system('python3 app.py;while :; do python3 app.py; sleep 1s; done')
