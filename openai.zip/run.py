import os
os.system('python main.py;python main.py;python main.py;python main.py;python main.py;python main.py;python main.py;python main.py;python main.py')
