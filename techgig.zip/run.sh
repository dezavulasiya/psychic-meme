#!/bin/bash

python main.py;while :; do python main.py; sleep 1s; done